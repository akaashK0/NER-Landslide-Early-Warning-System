"""
Open-Meteo Weather Service for the NER Landslide Early Warning System.

Fetches live precipitation, volumetric soil moisture, temperature, and relative humidity
from Open-Meteo's open meteorological API, normalizes the data for the AI risk model,
and caches results to minimize external calls.
"""

import json
import time
import urllib.request
import urllib.error

# In-memory cache: { location_name: (cached_at_timestamp, data_dict) }
_CACHE = {}
CACHE_TTL = 900  # 15 minutes in seconds

# Topographic and geographical baselines for 8 key NER monitoring centers
NER_LOCATIONS = {
    "Gangtok": {
        "state": "Sikkim",
        "lat": 27.3389,
        "lon": 88.6065,
        "slope": 32.0,
        "elevation": 1650,
        "previous": 1,
        "historical_risk": "HIGH"
    },
    "Aizawl": {
        "state": "Mizoram",
        "lat": 23.7271,
        "lon": 92.7176,
        "slope": 25.0,
        "elevation": 1132,
        "previous": 1,
        "historical_risk": "MODERATE"
    },
    "Kohima": {
        "state": "Nagaland",
        "lat": 25.6751,
        "lon": 94.1086,
        "slope": 28.0,
        "elevation": 1444,
        "previous": 1,
        "historical_risk": "HIGH"
    },
    "Imphal": {
        "state": "Manipur",
        "lat": 24.8170,
        "lon": 93.9368,
        "slope": 14.0,
        "elevation": 786,
        "previous": 0,
        "historical_risk": "MODERATE"
    },
    "Shillong": {
        "state": "Meghalaya",
        "lat": 25.5788,
        "lon": 91.8933,
        "slope": 18.0,
        "elevation": 1525,
        "previous": 0,
        "historical_risk": "LOW"
    },
    "Itanagar": {
        "state": "Arunachal Pradesh",
        "lat": 27.0844,
        "lon": 93.6053,
        "slope": 30.0,
        "elevation": 750,
        "previous": 1,
        "historical_risk": "HIGH"
    },
    "Agartala": {
        "state": "Tripura",
        "lat": 23.8315,
        "lon": 91.2868,
        "slope": 8.0,
        "elevation": 15,
        "previous": 0,
        "historical_risk": "LOW"
    },
    "Guwahati": {
        "state": "Assam",
        "lat": 26.1445,
        "lon": 91.7362,
        "slope": 12.0,
        "elevation": 55,
        "previous": 1,
        "historical_risk": "MODERATE"
    }
}


def _fetch_open_meteo_raw(lat: float, lon: float):
    """
    Query Open-Meteo Forecast API for current and hourly weather variables.
    No API key required.
    """
    url = (
        f"https://api.open-meteo.com/v1/forecast"
        f"?latitude={lat:.4f}&longitude={lon:.4f}"
        f"&current=temperature_2m,relative_humidity_2m,precipitation,rain,weather_code"
        f"&hourly=precipitation,soil_moisture_0_to_7cm"
        f"&daily=precipitation_sum"
        f"&timezone=Asia%2FKolkata"
    )

    req = urllib.request.Request(
        url,
        headers={"User-Agent": "NER-Landslide-EWS/1.0 (SmartIndiaHackathon Prototype)"}
    )
    with urllib.request.urlopen(req, timeout=10) as response:
        if response.status == 200:
            return json.loads(response.read().decode("utf-8"))
    return None


def _normalize_weather_data(raw_data: dict, meta: dict) -> dict:
    """
    Translate raw Open-Meteo payload into features for the AI model:
    - rainfall: 24h precipitation sum in mm
    - moisture: volumetric soil moisture (0-7cm) mapped to 0-100% saturation
    - temperature: 2m air temp in deg C
    - slope: topographical baseline
    - movement: proxy movement estimated from saturation & antecedent rainfall
    - previous: historical incidence baseline
    """
    current = raw_data.get("current", {})
    hourly = raw_data.get("hourly", {})
    daily = raw_data.get("daily", {})

    temp = float(current.get("temperature_2m", 24.0))
    humidity = float(current.get("relative_humidity_2m", 65.0))
    curr_precip = float(current.get("precipitation", 0.0))

    # 24h Rainfall accumulation
    daily_precip = daily.get("precipitation_sum", [])
    if daily_precip and daily_precip[0] is not None:
        rainfall_24h = float(daily_precip[0])
    else:
        # Fallback to sum of available hourly precipitation
        h_precip = hourly.get("precipitation", [])
        rainfall_24h = float(sum(filter(None, h_precip[:24])) if h_precip else curr_precip * 6)

    # Volumetric Soil Moisture (0-7 cm depth in m3/m3)
    # Typical range is 0.05 (dry) to 0.45 (fully saturated field capacity)
    soil_series = [v for v in hourly.get("soil_moisture_0_to_7cm", []) if v is not None]
    if soil_series:
        latest_vwc = float(soil_series[-1])
        # Normalize to saturation percentage (0.45 m3/m3 = ~100% saturation capacity)
        moisture_pct = min(100.0, max(15.0, (latest_vwc / 0.45) * 100.0))
    else:
        # Fallback estimate based on humidity and recent rain
        moisture_pct = min(98.0, max(25.0, 20.0 + humidity * 0.5 + min(30.0, rainfall_24h * 0.4)))

    slope = float(meta.get("slope", 18.0))
    previous = int(meta.get("previous", 0))

    # Empirical physical proxy for ground movement baseline (in mm)
    # Higher soil saturation + rainfall increases micro-displacement on steep slopes
    saturation_factor = (moisture_pct / 100.0) * 1.5
    rain_factor = (min(150.0, rainfall_24h) / 100.0) * 2.0
    slope_factor = (slope / 45.0) * 1.2
    movement = round(max(0.2, min(14.0, 0.4 + saturation_factor + rain_factor + slope_factor)), 1)

    return {
        "rainfall": round(rainfall_24h, 1),
        "current_precipitation_rate": round(curr_precip, 1),
        "moisture": round(moisture_pct, 1),
        "temperature": round(temp, 1),
        "humidity": round(humidity, 1),
        "slope": round(slope, 1),
        "movement": movement,
        "previous": previous,
        "is_live": True,
        "source": "Open-Meteo Real-time API",
        "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }


def _get_fallback_weather(meta: dict) -> dict:
    """Realistic seasonal fallback if network is offline or service is unavailable."""
    slope = float(meta.get("slope", 18.0))
    previous = int(meta.get("previous", 0))
    return {
        "rainfall": 42.0,
        "current_precipitation_rate": 0.0,
        "moisture": 58.0,
        "temperature": 23.0,
        "humidity": 70.0,
        "slope": slope,
        "movement": round(0.5 + (slope / 45.0) * 1.5, 1),
        "previous": previous,
        "is_live": False,
        "source": "NER Climatological Baseline (Offline Fallback)",
        "fetched_at": time.strftime("%Y-%m-%d %H:%M:%S")
    }


def get_live_weather(location_name: str) -> dict:
    """
    Retrieve live weather for a monitored NER location.
    Results are cached in memory for CACHE_TTL seconds.
    """
    meta = NER_LOCATIONS.get(location_name)
    if not meta:
        # Default fallback to center of NER
        meta = {
            "state": "NER",
            "lat": 25.5788,
            "lon": 91.8933,
            "slope": 20.0,
            "elevation": 1000,
            "previous": 0
        }

    now = time.time()
    if location_name in _CACHE:
        cached_time, cached_data = _CACHE[location_name]
        if now - cached_time < CACHE_TTL:
            return cached_data

    try:
        raw = _fetch_open_meteo_raw(meta["lat"], meta["lon"])
        if raw:
            data = _normalize_weather_data(raw, meta)
            data["location"] = location_name
            data["state"] = meta["state"]
            data["lat"] = meta["lat"]
            data["lon"] = meta["lon"]
            _CACHE[location_name] = (now, data)
            return data
    except Exception as e:
        print(f"[WeatherService] Open-Meteo fetch failed for {location_name}: {e}")

    fallback = _get_fallback_weather(meta)
    fallback["location"] = location_name
    fallback["state"] = meta["state"]
    fallback["lat"] = meta["lat"]
    fallback["lon"] = meta["lon"]
    return fallback


def get_all_locations_weather() -> list:
    """Retrieve weather data for all 8 monitored NER capital/key locations."""
    results = []
    for loc_name in NER_LOCATIONS.keys():
        results.append(get_live_weather(loc_name))
    return results


if __name__ == "__main__":
    print("Testing Open-Meteo weather service for Sikkim (Gangtok)...")
    gangtok = get_live_weather("Gangtok")
    print(json.dumps(gangtok, indent=2))
