@echo off
echo ==========================================
echo NER Landslide EWS - SIH Prototype
echo ==========================================
if not exist venv (
  python -m venv venv
)
call venv\Scripts\activate
python -m pip install --upgrade pip
pip install -r requirements.txt
echo.
echo Starting dashboard...
python app.py
pause
