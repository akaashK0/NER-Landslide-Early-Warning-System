
"""
Real EO feature-preparation pipeline for the NER Landslide EWS prototype.

Input:
  - GeoTIFF/COG rasters downloaded from official/open EO portals.
  - Optional CSV rainfall/landslide inventory.

Expected raster examples:
  dem.tif          -> elevation
  ndvi.tif         -> vegetation indicator (Sentinel-2 or other EO product)
  vv.tif            -> Sentinel-1 VV backscatter
  vh.tif            -> Sentinel-1 VH backscatter
  slope.tif        -> slope in degrees (or derive from DEM with GIS tools)

This script calculates raster summary features for an AOI and writes
data/eo_features.csv. It intentionally does NOT claim that these values
are real-time or that the ML output is a certified warning.

Install:
  pip install rasterio pandas numpy

Usage:
  python data_pipeline.py
"""

from pathlib import Path
import numpy as np
import pandas as pd

DATA = Path("data")
DATA.mkdir(exist_ok=True)

def raster_stats(path):
    import rasterio
    with rasterio.open(path) as src:
        arr = src.read(1, masked=True).astype("float32")
        values = arr.compressed()
        if len(values) == 0:
            raise ValueError(f"No valid pixels in {path}")
        return {
            "mean": float(values.mean()),
            "median": float(np.median(values)),
            "min": float(values.min()),
            "max": float(values.max()),
            "std": float(values.std()),
            "crs": str(src.crs),
            "resolution_x": float(src.res[0]),
            "resolution_y": float(src.res[1])
        }

def main():
    files = {
        "elevation": DATA / "dem.tif",
        "ndvi": DATA / "ndvi.tif",
        "sentinel1_vv": DATA / "vv.tif",
        "sentinel1_vh": DATA / "vh.tif",
        "slope": DATA / "slope.tif",
    }

    row = {}
    provenance = []

    for name, path in files.items():
        if path.exists():
            stats = raster_stats(path)
            row[f"{name}_mean"] = stats["mean"]
            row[f"{name}_std"] = stats["std"]
            row[f"{name}_min"] = stats["min"]
            row[f"{name}_max"] = stats["max"]
            provenance.append(f"{name}: {path.name}")

    if not row:
        print("No GeoTIFFs found.")
        print("Download/prepare official EO rasters and place them in ./data/")
        return

    row["source_files"] = "; ".join(provenance)
    row["generated_at"] = pd.Timestamp.utcnow().isoformat()

    out = DATA / "eo_features.csv"
    pd.DataFrame([row]).to_csv(out, index=False)
    print(f"Wrote {out}")
    print(pd.DataFrame([row]).T.to_string(header=False))

if __name__ == "__main__":
    main()
