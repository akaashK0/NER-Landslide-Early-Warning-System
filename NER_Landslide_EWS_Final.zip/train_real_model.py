
"""
Template for training the final SIH model from REAL, documented data.

Input:
  data/training_dataset.csv

Required target:
  landslide_risk
  0=LOW, 1=MODERATE, 2=HIGH, 3=CRITICAL

Example feature columns:
  rainfall_24h, rainfall_7d, elevation_mean, slope_mean,
  ndvi_mean, sentinel1_vv_mean, sentinel1_vh_mean,
  soil_moisture, previous_incidents

Do not train on synthetic values for the final claim.
"""

from pathlib import Path
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report
import joblib

path = Path("data/training_dataset.csv")
if not path.exists():
    raise SystemExit("Create data/training_dataset.csv from documented real data first.")

df = pd.read_csv(path)
target = "landslide_risk"
features = [c for c in df.columns if c != target and df[c].dtype != "object"]

if target not in df:
    raise SystemExit(f"Missing target column: {target}")

X = df[features].fillna(df[features].median(numeric_only=True))
y = df[target]

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42, stratify=y
)

model = RandomForestClassifier(
    n_estimators=300, random_state=42, class_weight="balanced"
)
model.fit(X_train, y_train)

pred = model.predict(X_test)
print(classification_report(y_test, pred, zero_division=0))

Path("models").mkdir(exist_ok=True)
joblib.dump({"model": model, "features": features}, "models/ner_landslide_rf.joblib")
print("Saved models/ner_landslide_rf.joblib")
