let sim = false, timer = null;
let currentMode = "live";
let state = {rainfall: 0.2, moisture: 65, slope: 25, movement: 1.2, temp: 22};

const colors = {LOW: "#42d392", MODERATE: "#f2c94c", HIGH: "#f2994a", CRITICAL: "#eb5757"};

const riskChart = new Chart(document.getElementById("riskChart"), {
  type: "line",
  data: {
    labels: [],
    datasets: [{
      label: "Risk probability (%)",
      data: [],
      tension: 0.35,
      borderColor: "#38bdf8",
      backgroundColor: "rgba(56, 189, 248, 0.15)",
      fill: true
    }]
  },
  options: {
    responsive: true,
    scales: {
      y: {min: 0, max: 100, grid: {color: "#1a2c3f"}},
      x: {grid: {display: false}}
    },
    plugins: {
      legend: {labels: {color: "#94a3b8"}}
    }
  }
});

function setText(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function updateInputs() {
  setText("rainfall", Math.round(state.rainfall));
  setText("moisture", Math.round(state.moisture));
  setText("slope", state.slope.toFixed(1));
  setText("movement", state.movement.toFixed(1));
}

async function predict(isLive = (currentMode === "live")) {
  updateInputs();
  const location = document.getElementById("location").value;
  const previous = Number(document.getElementById("previous").value);

  const payload = {
    ...state,
    location: location,
    previous: previous,
    is_live: Boolean(isLive)
  };

  try {
    const res = await fetch("/api/predict", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(payload)
    });
    const d = await res.json();

    setText("risk", d.risk);
    setText("prob", d.probability + "%");
    setText("time", d.timestamp);

    // Apply color to the risk card
    const riskCard = document.querySelector(".risk-card");
    if (riskCard && colors[d.risk]) {
      riskCard.style.borderColor = colors[d.risk];
    }

    // Chart update
    riskChart.data.labels.push(d.timestamp);
    riskChart.data.datasets[0].data.push(d.probability);
    if (riskChart.data.labels.length > 12) {
      riskChart.data.labels.shift();
      riskChart.data.datasets[0].data.shift();
    }
    riskChart.update();

    // Warning Banner
    const warning = document.getElementById("warning");
    if (d.risk === "HIGH" || d.risk === "CRITICAL") {
      warning.classList.remove("hidden");
      setText("warningTitle", d.risk + " LANDSLIDE WARNING");
      setText("warningText", d.action);
    } else {
      warning.classList.add("hidden");
    }

    loadStats();
    loadAlerts();
  } catch (err) {
    console.error("Prediction error:", err);
  }
}

async function fetchAndApplyLive(locName) {
  const loc = locName || document.getElementById("location").value;
  setText("modeStatus", "Fetching Open-Meteo...");
  try {
    const res = await fetch(`/api/weather/live?location=${encodeURIComponent(loc)}`);
    const d = await res.json();

    state.rainfall = d.rainfall;
    state.moisture = d.moisture;
    state.slope = d.slope;
    state.movement = d.movement;
    state.temp = d.temperature;

    document.getElementById("temp").value = Math.round(d.temperature);
    setText("tempVal", Math.round(d.temperature));
    document.getElementById("previous").value = d.previous;

    currentMode = "live";
    setText("modeStatus", "Live telemetry");
    const srcText = d.source + (d.fetched_at ? " • " + d.fetched_at.split(" ")[1] : "");
    setText("sourceCaption", "Source: " + srcText);

    predict(true);
  } catch (err) {
    console.error("Failed to fetch live weather:", err);
    setText("modeStatus", "Offline fallback");
    predict(false);
  }
}

function onLocationChange() {
  if (sim) {
    toggleSimulation();
  }
  const loc = document.getElementById("location").value;
  fetchAndApplyLive(loc);
}

function predictManual() {
  if (sim) {
    toggleSimulation();
  }
  currentMode = "manual";
  state.temp = Number(document.getElementById("temp").value);
  setText("modeStatus", "Manual override");
  setText("sourceCaption", "Mode: Manual Parameter Evaluation");
  predict(false);
}

function randomize() {
  if (sim) {
    toggleSimulation();
  }
  currentMode = "simulation";
  state.rainfall = Math.round(15 + Math.random() * 55);
  state.moisture = Math.round(35 + Math.random() * 30);
  state.slope = Number((10 + Math.random() * 16).toFixed(1));
  state.movement = Number((Math.random() * 2.5).toFixed(1));
  state.temp = Math.round(18 + Math.random() * 10);

  document.getElementById("temp").value = state.temp;
  setText("tempVal", state.temp);
  setText("modeStatus", "Simulated demo");
  setText("sourceCaption", "Mode: Simulated Random Parameters");
  predict(false);
}

function toggleSimulation() {
  sim = !sim;
  const btn = document.getElementById("simulateBtn");
  btn.textContent = sim ? "■ Stop Simulation" : "▶ Start Simulation Mode";

  if (sim) {
    currentMode = "simulation";
    setText("modeStatus", "Live simulation auto-stepping");
    setText("sourceCaption", "Simulation: Stepping rainfall and ground displacement");
    timer = setInterval(() => {
      state.rainfall = Math.min(160, state.rainfall + Math.random() * 8);
      state.moisture = Math.min(99, state.moisture + Math.random() * 4);
      state.movement = Math.min(14, state.movement + Math.random() * 0.7);
      state.slope = Math.min(42, state.slope + Math.random() * 0.3);
      predict(false);
    }, 3000);
  } else {
    clearInterval(timer);
    setText("modeStatus", "Simulation paused");
  }
}

async function syncCurrentLive() {
  if (sim) {
    toggleSimulation();
  }
  await fetchAndApplyLive();
  await loadMapLocations();
}

async function loadStats() {
  try {
    const d = await (await fetch("/api/stats")).json();
    setText("totalAlerts", d.alerts);
    setText("highAlerts", d.high);
    setText("criticalAlerts", d.critical);
  } catch (e) {}
}

async function loadAlerts() {
  try {
    const rows = await (await fetch("/api/alerts")).json();
    const alertsDiv = document.getElementById("alerts");
    alertsDiv.innerHTML = rows.length
      ? rows.map(a =>
          `<div class="alert"><b style="color:${colors[a.risk] || '#fff'}">${a.risk}</b> ${a.location}<br><small>${a.created_at} · ${a.probability}% probability · Rain: ${a.rainfall}mm</small></div>`
        ).join("")
      : "<p style='color:#718aa1;padding:8px'>No high-risk alerts logged yet.</p>";
  } catch (e) {}
}

// ---------------- MAP INTEGRATION ----------------
const map = L.map("map").setView([25.4, 92.5], 6);
const osm = L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
  attribution: "© OpenStreetMap"
}).addTo(map);

// Bhuvan / NRSC-ISRO WMS thematic overlay
const bhuvanLULC = L.tileLayer.wms("https://bhuvan-vec2.nrsc.gov.in/bhuvan/wms", {
  layers: "lulc:BR_LULC50K_1112",
  format: "image/png",
  transparent: true,
  version: "1.1.1",
  attribution: "Bhuvan / NRSC / ISRO"
});

const overlays = {"Bhuvan-ISRO Thematic Layer": bhuvanLULC};
L.control.layers({"OpenStreetMap": osm}, overlays).addTo(map);

const markersLayer = L.layerGroup().addTo(map);

async function loadMapLocations() {
  try {
    const points = await (await fetch("/api/locations")).json();
    markersLayer.clearLayers();

    points.forEach(p => {
      const riskColor = colors[p.risk] || "#38bdf8";
      const marker = L.circleMarker([p.lat, p.lon], {
        radius: 10,
        color: riskColor,
        fillColor: riskColor,
        fillOpacity: 0.85,
        weight: 2
      });

      const popupHtml = `
        <div style="min-width:180px">
          <strong style="font-size:14px">${p.name}</strong> <span style="color:#94a3b8;font-size:12px">(${p.state})</span>
          <br>
          <span class="popup-risk-badge" style="background:${riskColor}">${p.risk} RISK (${p.probability}%)</span>
          <div class="popup-stat-grid">
            <div>24h Rain: <b>${p.rainfall} mm</b></div>
            <div>Moisture: <b>${p.moisture}%</b></div>
            <div>Air Temp: <b>${p.temperature} °C</b></div>
            <div>Slope: <b>${p.slope}°</b></div>
          </div>
          <div style="margin-top:7px;display:flex;justify-content:space-between;align-items:center">
            <small style="color:#38bdf8">${p.source}</small>
            <button style="padding:3px 8px;font-size:10px;background:#1e3a5f;color:#fff;border-radius:4px" onclick="selectLocationFromMap('${p.name}')">Inspect</button>
          </div>
        </div>
      `;

      marker.bindPopup(popupHtml);
      marker.on("click", () => {
        selectLocationFromMap(p.name);
      });

      marker.addTo(markersLayer);
    });
  } catch (err) {
    console.error("Failed to load map locations:", err);
  }
}

function selectLocationFromMap(name) {
  const locSelect = document.getElementById("location");
  if (locSelect) {
    locSelect.value = name;
    fetchAndApplyLive(name);
  }
}

// Initial Boot Sequence
fetchAndApplyLive("Gangtok");
loadMapLocations();
loadStats();
loadAlerts();
