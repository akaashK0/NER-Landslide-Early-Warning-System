
# Official/open data plan for the SIH prototype

## 1. Bhuvan / NRSC / ISRO
Official Indian Geo Platform of ISRO/NRSC:
https://bhuvan.nrsc.gov.in/

Bhuvan provides free satellite-data access, thematic data and disaster services.
Its site documents landslide-related disaster services and EO products.

## 2. Copernicus Sentinel-1
Official Copernicus Data Space:
https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-1

Use Sentinel-1 GRD for a beginner-friendly first prototype. SAR can observe
surface conditions regardless of daylight and is much less affected by cloud cover.

## 3. Copernicus Sentinel-2
Official Copernicus Data Space:
https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-2

Use Sentinel-2 L2A where available for multispectral vegetation/land-surface
features such as NDVI.

## 4. Government of India Open Data
https://www.data.gov.in/

The OGD platform is the Government of India's open-data portal. It includes
disaster-management datasets and state portals. Use it for documented supporting
statistics where an appropriate NER dataset is available.

## 5. Historical landslide reference
Bhuvan/NRSC has published landslide-related disaster products and reports. One
example is the Sikkim earthquake landslide inventory report, which documents
354 new and 48 old landslides after the 18 September 2011 event.

Use published inventory/event data as labels only after checking its geographic
coverage, date, scale and licensing/usage terms.

## Important
Do not mix dates/areas without recording them. Every training row should retain:
- source
- acquisition/event date
- AOI
- product name/processing level
- spatial resolution
- preprocessing steps
- target/label source

The dashboard's simulated mode is for demonstration only.
