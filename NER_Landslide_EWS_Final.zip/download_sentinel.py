
"""
Search Copernicus Data Space for Sentinel-1/2 products covering the NER.

This script uses the public Copernicus catalogue search. Product downloads require
a Copernicus Data Space account/access token. The script never stores a password.

Run:
    python download_sentinel.py

You can change the date range and bbox below.
NER-wide bbox is approximate:
longitude 88.0 to 97.5, latitude 21.5 to 29.5.

For a faster demo, use a smaller AOI around one study site such as Sikkim.
"""
import requests, json, os
from pathlib import Path

CATALOG = "https://sh.dataspace.copernicus.eu/catalog/v1/search"
DOWNLOAD = "https://download.dataspace.copernicus.eu/odata/v1/Products"

# Smaller Sikkim AOI is recommended for a first run.
BBOX = [87.9, 26.8, 88.95, 28.2]
DATE_FROM = "2024-06-01T00:00:00Z"
DATE_TO   = "2024-09-30T23:59:59Z"

def search(collection, limit=5):
    payload = {
        "bbox": BBOX,
        "datetime": f"{DATE_FROM}/{DATE_TO}",
        "collections": [collection],
        "limit": limit
    }
    r = requests.post(CATALOG, json=payload, timeout=60)
    r.raise_for_status()
    return r.json()

def main():
    print("NER/Sikkim Sentinel catalogue search")
    print("BBOX:", BBOX)
    for collection in ["sentinel-1-grd", "sentinel-2-l2a"]:
        print("\n---", collection, "---")
        try:
            data = search(collection)
            feats = data.get("features", [])
            if not feats:
                print("No products found for this date/AOI.")
                continue
            for i, f in enumerate(feats, 1):
                p = f.get("properties", {})
                print(f"{i}. {f.get('id')}")
                print("   date:", p.get("datetime"))
                print("   name:", p.get("title") or p.get("name"))
                print("   bbox:", f.get("bbox"))
            print("\nCatalogue search successful.")
        except Exception as e:
            print("Search failed:", e)

    print("\nTo download a product, use Copernicus Data Space authentication and the")
    print("official OData download endpoint. See the README for the official docs.")

if __name__ == "__main__":
    main()
