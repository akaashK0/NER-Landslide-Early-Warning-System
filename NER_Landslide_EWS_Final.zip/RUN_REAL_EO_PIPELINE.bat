@echo off
call venv\Scripts\activate
pip install -r requirements_real_eo.txt
python download_sentinel.py
echo.
echo After downloading and preprocessing official EO data into data\*.tif:
echo python data_pipeline.py
echo python train_real_model.py
pause
