from flask import Flask, render_template, jsonify, request
from datetime import datetime
import random, sqlite3, os
import numpy as np
from sklearn.ensemble import RandomForestClassifier
import weather_service

app = Flask(__name__)
DB = "landslide.db"

# ---------------- AI MODEL ----------------
# Synthetic training data for a demonstrable prototype.
# Features: rainfall(mm), soil moisture(%), slope(deg), ground movement(mm),
# temperature(C), previous incidents(0/1)
def make_training_data(n=5000):
    rng = np.random.default_rng(42)
    rainfall = rng.uniform(0, 180, n)
    moisture = rng.uniform(20, 100, n)
    slope = rng.uniform(2, 45, n)
    movement = rng.uniform(0, 15, n)
    temp = rng.uniform(10, 35, n)
    previous = rng.integers(0, 2, n)

    score = (
        rainfall * 0.30 +
        moisture * 0.25 +
        slope * 1.2 +
        movement * 3.5 +
        previous * 8 +
        np.maximum(rainfall - 80, 0) * 0.20
    )
    y = np.select(
        [score < 55, score < 85, score < 115],
        [0, 1, 2],
        default=3
    )
    X = np.column_stack([rainfall, moisture, slope, movement, temp, previous])
    return X, y

X, y = make_training_data()
model = RandomForestClassifier(n_estimators=150, random_state=42, max_depth=10)
model.fit(X, y)

LABELS = ["LOW", "MODERATE", "HIGH", "CRITICAL"]
ACTIONS = {
    "LOW": "Continue monitoring conditions.",
    "MODERATE": "Increase monitoring and inspect vulnerable slopes.",
    "HIGH": "Issue a local warning and restrict access to vulnerable slopes.",
    "CRITICAL": "Activate emergency warning procedures and follow local authority instructions."
}

# ---------------- DATABASE ----------------
def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS alerts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            location TEXT,
            risk TEXT,
            probability REAL,
            rainfall REAL,
            moisture REAL,
            slope REAL,
            movement REAL,
            created_at TEXT
        )
    """)
    conn.commit()
    conn.close()

init_db()

# ---------------- ROUTES ----------------
@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/predict", methods=["POST"])
def predict():
    data = request.get_json(force=True)
    vals = [
        float(data.get("rainfall", 0)),
        float(data.get("moisture", 0)),
        float(data.get("slope", 0)),
        float(data.get("movement", 0)),
        float(data.get("temperature", 25)),
        int(data.get("previous", 0))
    ]
    pred = int(model.predict([vals])[0])
    probs = model.predict_proba([vals])[0]
    probability = float(probs[pred]) * 100
    risk = LABELS[pred]
    location = data.get("location", "Demo Location")

    if risk in ("HIGH", "CRITICAL"):
        conn = db()
        conn.execute("""
            INSERT INTO alerts
            (location,risk,probability,rainfall,moisture,slope,movement,created_at)
            VALUES (?,?,?,?,?,?,?,?)
        """, (
            location, risk, round(probability, 2),
            vals[0], vals[1], vals[2], vals[3],
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ))
        conn.commit()
        conn.close()

    is_live = bool(data.get("is_live", False))
    return jsonify({
        "risk": risk,
        "probability": round(probability, 2),
        "action": ACTIONS[risk],
        "timestamp": datetime.now().strftime("%H:%M:%S"),
        "is_live": is_live,
        "source": "Open-Meteo Real-time API" if is_live else "Simulation"
    })

@app.route("/api/weather/live")
def weather_live():
    loc = request.args.get("location", "Gangtok")
    weather = weather_service.get_live_weather(loc)
    vals = [
        float(weather.get("rainfall", 0)),
        float(weather.get("moisture", 0)),
        float(weather.get("slope", 0)),
        float(weather.get("movement", 0)),
        float(weather.get("temperature", 25)),
        int(weather.get("previous", 0))
    ]
    pred = int(model.predict([vals])[0])
    probs = model.predict_proba([vals])[0]
    probability = float(probs[pred]) * 100
    risk = LABELS[pred]

    return jsonify({
        **weather,
        "risk": risk,
        "probability": round(probability, 2),
        "action": ACTIONS[risk]
    })

@app.route("/api/alerts")
def alerts():
    conn = db()
    rows = conn.execute(
        "SELECT * FROM alerts ORDER BY id DESC LIMIT 20"
    ).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/stats")
def stats():
    conn = db()
    total = conn.execute("SELECT COUNT(*) c FROM alerts").fetchone()["c"]
    critical = conn.execute(
        "SELECT COUNT(*) c FROM alerts WHERE risk='CRITICAL'"
    ).fetchone()["c"]
    high = conn.execute(
        "SELECT COUNT(*) c FROM alerts WHERE risk='HIGH'"
    ).fetchone()["c"]
    conn.close()
    return jsonify({"alerts": total, "critical": critical, "high": high})

@app.route("/api/data-sources")
def data_sources():
    return jsonify([
        {
            "name": "Open-Meteo Weather API",
            "provider": "Open-Meteo / ECMWF / DWD / NOAA",
            "type": "Live Open Meteorological & Soil Moisture API",
            "use": "Live precipitation, volumetric soil moisture (0-7cm), 2m temperature & humidity for active EWS triggering",
            "url": "https://open-meteo.com/"
        },
        {
            "name": "Bhuvan / NRSC-ISRO",
            "provider": "Government of India - ISRO / NRSC",
            "type": "Indian EO / thematic geospatial services",
            "use": "Base imagery, terrain/thematic layers and Indian geospatial context",
            "url": "https://bhuvan.nrsc.gov.in/"
        },
        {
            "name": "Bhuvan Open EO Data Archive",
            "provider": "Government of India - NRSC",
            "type": "Open Earth Observation archive",
            "use": "Downloadable Indian satellite/elevation datasets",
            "url": "https://bhuvan-app3.nrsc.gov.in/data"
        },
        {
            "name": "Copernicus Sentinel-1",
            "provider": "European Union / ESA",
            "type": "C-band SAR",
            "use": "All-weather surface-change / ground-motion analysis",
            "url": "https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-1"
        },
        {
            "name": "Copernicus Sentinel-2",
            "provider": "European Union / ESA",
            "type": "Multispectral optical",
            "use": "Vegetation, land-cover and surface-condition indices",
            "url": "https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-2"
        }
    ])

@app.route("/api/bhuvan-config")
def bhuvan_config():
    return jsonify({
        "wms_url": "https://bhuvan-vec2.nrsc.gov.in/bhuvan/wms",
        "version": "1.1.1",
        "sample_lulc_layer": "lulc:BR_LULC50K_1112",
        "note": "Bhuvan WMS layer names vary by theme/year. Select the current layer from Bhuvan Thematic Services before production deployment."
    })

@app.route("/api/locations")
def locations():
    # Dynamically retrieves weather from Open-Meteo for all 8 NER monitored centers
    # and computes AI landslide risk based on real-time parameters
    locations_data = []
    weather_list = weather_service.get_all_locations_weather()
    
    for w in weather_list:
        vals = [
            float(w.get("rainfall", 0)),
            float(w.get("moisture", 0)),
            float(w.get("slope", 0)),
            float(w.get("movement", 0)),
            float(w.get("temperature", 25)),
            int(w.get("previous", 0))
        ]
        pred = int(model.predict([vals])[0])
        probs = model.predict_proba([vals])[0]
        probability = float(probs[pred]) * 100
        risk = LABELS[pred]

        locations_data.append({
            "name": w.get("location"),
            "state": w.get("state"),
            "lat": w.get("lat"),
            "lon": w.get("lon"),
            "risk": risk,
            "probability": round(probability, 1),
            "rainfall": w.get("rainfall"),
            "moisture": w.get("moisture"),
            "temperature": w.get("temperature"),
            "humidity": w.get("humidity"),
            "slope": w.get("slope"),
            "movement": w.get("movement"),
            "is_live": w.get("is_live", False),
            "source": w.get("source", "Open-Meteo API")
        })

    return jsonify(locations_data)

if __name__ == "__main__":
    app.run(debug=True)
