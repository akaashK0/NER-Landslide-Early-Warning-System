
PUT DOWNLOADED/PROCESSED GEO-TIFFS HERE

Suggested files:
  dem.tif    = elevation / DEM
  slope.tif  = slope in degrees
  ndvi.tif   = vegetation index derived from Sentinel-2
  vv.tif     = Sentinel-1 VV backscatter
  vh.tif     = Sentinel-1 VH backscatter

The files should cover the same NER area/AOI and preferably the same analysis
period or clearly documented acquisition dates.

OFFICIAL / OPEN DATA SOURCES
1) Bhuvan / NRSC-ISRO / Government of India:
   https://bhuvan.nrsc.gov.in/
   Open EO Data Archive is available through Bhuvan.

2) Copernicus Data Space:
   Sentinel-1:
   https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-1
   Sentinel-2:
   https://dataspace.copernicus.eu/data-collections/copernicus-sentinel-missions/sentinel-2

3) For a serious model, combine EO features with:
   - validated historical landslide inventory
   - rainfall/time-series observations
   - geology/soil
   - DEM-derived slope/aspect/curvature
   - drainage/roads/settlements
   - land cover/vegetation

Do not use this demo as a real-world warning system.
