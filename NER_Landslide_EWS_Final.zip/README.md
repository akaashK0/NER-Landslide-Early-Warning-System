# AI-Based Early Warning and Landslide Risk Monitoring System in NER

A complete software-only SIH prototype. No ESP32, sensors, or hardware are required.

## Features
- **Live Weather Ingestion:** Real-time Open-Meteo API integration providing 24h precipitation sum, volumetric surface soil moisture (0-7cm), 2m air temperature, and humidity for 8 NER state centers without needing an API key.
- **Topographic & Hazard Baseline Registry:** Elevation, slope angle, and historical landslide susceptibility baselines mapped per NER state.
- **AI-Based Risk Classification:** Random Forest classifier computing probabilities across LOW, MODERATE, HIGH, and CRITICAL risk levels.
- **In-Memory Caching & Offline Fallback:** 15-minute TTL caching to avoid rate-limiting, with robust offline fallback.
- **GIS Monitoring Map:** Interactive Leaflet map with live weather stats per marker, plus ISRO Bhuvan WMS thematic overlay.
- **Warning System:** High/Critical hazard banners with recommended action guidance.
- **Alert History & Analytics:** SQLite persistence for severe alerts, with trend tracking via Chart.js.
- **Simulation & Manual Modes:** Flexibility to test extreme weather scenarios (e.g. cloudbursts) or switch to live telemetry.

## Run on Windows
1. Install Python 3.10+.
2. Open Command Prompt in this folder.
3. Run:
   python -m venv venv
   venv\Scripts\activate
   pip install -r requirements.txt
   python app.py
4. Open http://127.0.0.1:5000

## Run on macOS/Linux
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
python app.py

## Important prototype note
The model is trained on synthetic demonstration data. The map values are also simulated.
For a production/SIH final system, replace these with validated historical rainfall,
terrain, soil, geological, satellite/remote-sensing and incident datasets.


## Government/open EO data integration

This version is designed around official/open Earth Observation sources:

1. **Bhuvan / NRSC / ISRO (Government of India)**  
   Bhuvan provides Indian Earth-observation visualization, thematic layers and an Open EO Data Archive.
   The dashboard includes a Bhuvan WMS overlay configuration.

2. **Bhuvan Open EO Data Archive**  
   Use downloaded Indian satellite/elevation products to build a real training dataset.
   For production, document the exact product, acquisition date, processing level and license/terms.

3. **Copernicus Sentinel-1**  
   Radar imagery can support surface-change and ground-motion analysis and works day/night and through clouds.

4. **Copernicus Sentinel-2**  
   Multispectral imagery can support vegetation/land-surface indicators such as NDVI.

### Recommended real-data pipeline

Satellite scenes -> cloud/quality filtering -> terrain correction -> feature extraction ->
rainfall/soil/terrain features -> labelled landslide inventory -> ML training ->
risk map -> dashboard -> human/authority review.

### Important
The current prototype does NOT silently pretend that synthetic numbers are satellite observations.
It clearly separates:
- live geospatial map layers,
- downloadable/open EO data,
- simulated demo inputs, and
- AI predictions.

For a serious SIH submission, train and validate the model using documented historical landslide events and real EO-derived features.


# REAL-EO SIH IMPLEMENTATION

This package now includes:
- `data_pipeline.py` for extracting features from downloaded GeoTIFFs.
- `train_real_model.py` for training on a labelled real dataset.
- `data/README.txt` documenting the expected real EO inputs.
- `requirements_real_eo.txt` for raster processing.

## Recommended SIH evidence

In your presentation, show:
1. The official source/product name.
2. Acquisition date and spatial coverage.
3. Processing steps.
4. Extracted EO features.
5. Historical landslide labels.
6. Train/test split and metrics.
7. A risk map generated from the validated model.

## Data-source facts

Bhuvan is operated by NRSC/ISRO, Government of India, and provides visualization,
Open EO data and geospatial web services. Its documentation describes OGC services
including WMS/WMTS/WFS/WCS.

Copernicus Data Space provides Sentinel-1 and Sentinel-2 data. Sentinel-1 provides
SAR observations useful for surface-change monitoring; Sentinel-2 provides
multispectral observations useful for land/vegetation indicators.

The exact product, access conditions, acquisition dates and layer names must be
recorded for the datasets actually used. Do not label simulated values as satellite
measurements.

## Final architecture

Official EO data
  -> AOI filtering
  -> preprocessing
  -> terrain/vegetation/radar feature extraction
  -> rainfall + historical landslide labels
  -> ML model
  -> probability/risk class
  -> NER map
  -> early-warning dashboard
  -> human/authority review

This is a research/demo architecture, not a certified public warning service.


# EASIEST REAL-DATA PATH

Start with **Sikkim**, not the entire NER. It keeps the first satellite download and
processing manageable.

### A. Start the dashboard
Windows:
    RUN_ON_WINDOWS.bat

### B. Search official Sentinel products
After activating the venv:
    python download_sentinel.py

The script searches Copernicus Data Space's official catalogue for Sentinel-1 GRD
and Sentinel-2 L2A over a Sikkim bounding box. It does not fake or embed satellite
measurements.

### C. Download
Copernicus Data Space requires authenticated access for product downloads. Create
your account/token through the official Copernicus Data Space documentation.
Never put your password into source code or upload credentials.

### D. Preprocess
Convert/clip the downloaded products to the same AOI and export GeoTIFF features:
    dem.tif
    slope.tif
    ndvi.tif
    vv.tif
    vh.tif

Then:
    python data_pipeline.py

### E. Build the labelled training table
Combine EO features with a documented historical landslide inventory/event table:
    data/training_dataset.csv

Then:
    python train_real_model.py

### F. Connect the trained model
The next engineering step is replacing the demo Random Forest in `app.py` with
`models/ner_landslide_rf.joblib`, using exactly the same feature columns used during
training.

## Why the prototype starts with Sikkim
A small study area is easier to process and validate. After the pipeline works,
repeat it for additional NER states and merge the state/AOI outputs into the
regional dashboard.
